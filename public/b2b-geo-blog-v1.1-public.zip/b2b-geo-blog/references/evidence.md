# 证据、时效性与计量

## 轻量 evidence ledger

重要数字、因果主张、平台功能、客户效果需要记录：claim ID 与文章/小节；主张；直接来源标题、发布者和 URL；发表/版本日期（没显示则如实说明）；实际核查日期；支持段落/表格/页码；对象、样本、时期、指标、平台；证据类型与局限；保留/限定/更新/删除/未核实的处理。

按主张找证据：平台能力看该产品当前官方文档；研究数字读实际研究的方法和结果；客户效果查授权项目材料；工作模板标为编辑建议。一手来源仍需检查样本和方法，不等于结论无条件正确。批量文章可共享 ledger，保留逐篇 claim 映射，避免每篇复制无关来源附录。

引用靠近具体句子或表格来源单元格。只读搜索摘要不算核实，正文不要出现 turnXXXX、filecite 或未解析占位符。数据配额按 data-visuals.md 执行，不为凑配额添加无关来源；单一平台规则可以由一个直接官方说明支持，广泛因果或普遍结论需要相应强度的独立证据，证据不足就收窄。

## 时效性和访问故障

- 平台报告、爬虫角色、富结果支持会变化。执行时打开原始文档并核实当前范围，不把 skill 中的旧结论当现状。
- 新的具体产品帮助页与旧的概览有差异时，对照记录；优先使用直接覆盖该问题的当前说明，保留未解决的冲突。文档宣布已推出，不等于已核实某个账号实际有该报告。
- HEAD 或一次 GET 的 403/超时不能直接判定失效。可改合理 GET、研究工具或普通浏览器；不绕过访问控制。没有读到就标未核实、收窄/删除关键时效性主张，不假装“最新核查完成”。
- 记录检查日期与发表日期，二者不是一回事。素材中的“已确认”须对照本次用户/项目证据，不自动复制为作者或品牌事实。

## 计量不能偷换

| 概念 | 观察含义 / 边界 |
|---|---|
| Accessible | 在记录的请求条件下可访问，不代表已索引 |
| Indexed | 进入一个指定索引，不是所有产品共用一个索引 |
| Retrieved | 检索获取了信息；外部证据未必能完整证明内部过程 |
| Cited | 最终回答附链接或明确来源标记；仍要核对是否支持邻近主张 |
| Mentioned | 提及品牌，不一定推荐或链接官网 |
| Recommended | 按事先定义规则，被列为适合当前需求的选择 |
| Referral | 可识别来源的访问，不等于全部 AI 影响 |
| Qualified inquiry | 按约定适配标准确认的有效询盘，保留测试/垃圾/重复处理规则 |
| Revenue | 实际业务收入，不能用点击、提交或预测替代 |

这些是分析维度，不是所有平台公开的必然流水线。不画成“抓取 → 引用 → 推荐 → 购买”的必然转化漏斗。

研究使用时分清相对变化/百分点、相关/因果、统计不显著/证明无效、同期增长/归因增长、页面/回答/用户/session/询盘。基线 20% 到 30% 是 +10 个百分点或 +50% 相对变化；零基线不能硬算相对增长。不同人群或不同题目的比例不能拼成漏斗或排名。

观察性匹配、准实验、随机实验、单页诊断、平台政策、机制解释必须分别标识。事实提取能力不能直接当引用频率，搜索 CTR 不能当 AI 推荐率。反证和方法冲突要透明说明，不能挑一个有利版本。

## 没有证据时

依次：查授权材料与直接来源 → 收窄 → 换成不依赖该数字的具体解释 → 用标清的假设示范 → 删去非必要主张。示范数值不能计作研究统计。若核心问题仍无法回答，在交接说明证据缺口，不发布空洞占位稿。

## 官方与研究入口（使用前再打开）

以下是核查入口，不是缓存结论，也不是每篇必引清单。

| 场景 | 直接入口 | 要核查什么 |
|---|---|---|
| Google 生成式搜索 | https://developers.google.com/search/docs/fundamentals/ai-optimization-guide | SEO 关系、写作/格式误解、适用平台 |
| 读者价值与日期 | https://developers.google.com/search/docs/fundamentals/creating-helpful-content | 内容、署名、字数和更新时间的实际说明 |
| Google AI 功能 | https://developers.google.com/search/docs/appearance/ai-features | 技术条件、query fan-out、概览与具体报告的差异 |
| 功能变更 | https://developers.google.com/search/updates | FAQ 等功能是否仍支持，以及生效日期 |
| Search Console AI 报告 | https://support.google.com/webmasters/answer/16984139 | 当前报告是否存在、功能范围、指标、维度、聚合与 Web 数据重叠、可见性和导出限制；若地址变化，从官方帮助目录核实 |
| OpenAI 爬虫 | https://developers.openai.com/api/docs/bots | 搜索、训练和用户触发访问的当前角色及独立控制 |
| 标题展示 | https://developers.google.com/search/docs/appearance/title-link | 标题来源、改写和截断，不把字符数当排名规则 |
| 结构化数据 | https://developers.google.com/search/docs/appearance/structured-data/sd-policies | 可见事实一致性、真实性、适用条件 |
| Article 标记 | https://developers.google.com/search/docs/appearance/structured-data/article | author、headline、日期和推荐字段，先看项目已有输出 |
| Schema 引用研究 | https://ahrefs.com/blog/schema-ai-citations/ | 原始设计、样本、估计与不确定性，不能永久泛化 |
| Schema 提取诊断 | https://www.searchviu.com/en/schema-markup-and-ai-in-2025-what-chatgpt-claude-perplexity-gemini-really-see/ | 历史测试条件、重复次数描述、直接抓取与索引模式 |
| B2B 调查 | https://6sense.com/science-of-b2b/buyer-experience-report-2025/ | 具体题目、主调查/补充样本、AI 使用不等于归因销售 |
| 技术采购调查 | https://www.trustradius.com/blog/beyond-the-hype | 调查时期、样本、激励和不同题目口径 |
| GEO 术语研究 | https://arxiv.org/abs/2311.09735 | 进入全文读方法和限制；历史 benchmark 不等于现实平台预期效果 |

方法本身可以有价值，但文章仍须核对约定的数据配额；资料不足明确缺项，不用无关调查充数。
