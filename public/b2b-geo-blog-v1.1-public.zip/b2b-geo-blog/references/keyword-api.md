# 关键词 API 接入

工具：DataForSEO Labs Google Keyword Overview。

官方文档：https://docs.dataforseo.com/v3/dataforseo_labs-google-keyword_overview-live/
当前价格：https://dataforseo.com/pricing/dataforseo-labs/dataforseo-google-api

本包不包含账户或凭据。每位使用者在自己的机器上配置 DATAFORSEO_LOGIN 与 DATAFORSEO_PASSWORD，或通过 DATAFORSEO_CREDENTIALS_FILE 指定只允许本人读取的 JSON 文件，字段为 login 和 password。凭据不进入文章、仓库或分享包。

运行 python3 scripts/keyword_metrics.py keywords.json --location 2840 --language en --out run-folder 可预览请求；输入文件是关键词字符串组成的 JSON 数组。只有添加 --live 才会请求正式 API，可能产生费用。先核实当前定价、市场与预算；脚本不自动扩词、重试或充值。

每次核对返回的市场、时间、搜索量、难度与缺项。缺失不能记为零，不同供应商的难度不可直接等同。关键词数据只是选题依据之一，还要核查搜索意图与业务相关性。

本包的安装检查与离线测试不等于验证了任何使用者的 API 账户，也不证明文章能获得排名或 AI 引用。
