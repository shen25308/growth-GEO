#!/usr/bin/env python3
"""Offline behavior checks for the rendered-HTML summary checker."""
import check_tldr as m

body='<article><section id="summary"><h2>TL;DR</h2><ul><li>Answer.</li><li>Action.</li><li>Boundary.</li></ul></section><section><h2>Details</h2><p>Body text.</p></section></article>'
valid='<nav><a href="#summary">TL;DR</a></nav>'+body
cases=[
('valid',valid,False),
('missing-body-summary','<nav>TL;DR</nav><article><h2>Details</h2><p>Body</p></article>',True),
('metadata-only','<script type="application/ld+json">{"title":"TL;DR"}</script><article><p>Body</p></article>',True),
('late-summary',valid.replace('<article>','<article><h2>Earlier section</h2>'),True),
('duplicate-id',valid+'<div id="summary"></div>',True),
('too-few-points',valid.replace('<li>Boundary.</li>',''),True),
('empty-point',valid.replace('<li>Boundary.</li>','<li> </li>'),True),
('hidden-summary',valid.replace('id="summary"','id="summary" hidden'),True),
('wrong-page-toc',valid.replace('href="#summary"','href="/elsewhere#summary"'),True),
('no-toc',body,True),
('ambiguous-body',valid+body,True),
('main-is-not-summary-anchor','<nav><a href="#main">TL;DR</a></nav><main id="main">'+body.replace(' id="summary"','')+'</main>',True),
('canonical-toc','<link rel="canonical" href="https://example.com/guide">'+valid.replace('href="#summary"','href="https://example.com/guide#summary"'),False),
]
for name,html,expect_fail in cases:
 result=m.audit(html);assert bool(result['errors'])==expect_fail,(name,result)
assert not m.audit(body,require_toc=False)['errors']
assert not m.audit(valid.replace('<article>','<article class="actual">')+'<article>card</article>',article_class='actual')['errors']
print('15 structural behavior checks passed.')
