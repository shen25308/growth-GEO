#!/usr/bin/env python3
"""Create the portable prompt from the canonical skill and its references."""
from pathlib import Path
import argparse
import re

REFERENCES = [('positioning.md', 'positioning'), ('editorial.md', 'editorial'), ('research-seo.md', 'research-seo'), ('article-modes.md', 'article-modes'), ('data-visuals.md', 'data-visuals'), ('evidence.md', 'evidence'), ('iteration.md', 'iteration'), ('website.md', 'website'), ('topic-playbooks.md', 'topic-playbooks'), ('delivery.md', 'delivery'), ('keyword-api.md', 'keyword-api'), ('brand-config.md', 'brand-config')]


def render(root):
    text = (root / 'SKILL.md').read_text(encoding='utf-8')
    text = re.sub(r'\A---\n.*?\n---\n', '', text, count=1, flags=re.S).lstrip()
    for filename, anchor in REFERENCES:
        text = text.replace(f'(references/{filename})', f'(#{anchor})')
    output = ['# B2B GEO Blog v1.1-public — 完整写作与落地 Prompt', '',
              '本文件由 SKILL.md 与 references 自动汇总。只应用当前任务对应的分节；项目快照不覆盖用户的当前指令。检查脚本只在 skill 安装包内可用，纯文本模式用项目工具核验，不假称执行过脚本。', '', text]
    for filename, anchor in REFERENCES:
        content = (root / 'references' / filename).read_text(encoding='utf-8')
        for other, dest in REFERENCES:
            content = content.replace(f'({other})', f'(#{dest})')
        output += ['\n---\n', f'<a id="{anchor}"></a>', content]
    return '\n'.join(output).rstrip() + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    args.output.write_text(render(root), encoding='utf-8')


if __name__ == '__main__':
    main()
