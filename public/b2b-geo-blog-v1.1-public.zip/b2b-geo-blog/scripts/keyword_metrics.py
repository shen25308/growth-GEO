#!/usr/bin/env python3
"""One batch of DataForSEO metrics. Default: dry run; no automatic retries."""
import argparse,base64,json,os,time,urllib.request,urllib.error
from pathlib import Path
from datetime import datetime,timezone
URL='https://api.dataforseo.com/v3/dataforseo_labs/google/keyword_overview/live'
def normalize(raw,keywords,location,language):
    if raw.get('status_code')!=20000 or raw.get('tasks_error',0):
        raise ValueError('API request failed; see raw response status')
    tasks=raw.get('tasks') or []
    if len(tasks)!=1 or tasks[0].get('status_code')!=20000:
        raise ValueError('Expected one successful task')
    found={}
    for result in tasks[0].get('result') or []:
        if result.get('location_code')!=location or result.get('language_code')!=language:
            raise ValueError('Response market mismatch')
        for item in result.get('items') or []:
            found[item['keyword'].lower()]=item
    rows=[]
    for k in keywords:
        i=found.get(k,{})
        info=i.get('keyword_info') or {}; props=i.get('keyword_properties') or {}
        v=info.get('search_volume'); kd=props.get('keyword_difficulty')
        rows.append({'keyword':k,'search_volume':v,'keyword_difficulty':kd,'updated_at':info.get('last_updated_time'),'status':'missing' if not i else 'complete' if v is not None and kd is not None else 'partial','intent':(i.get('search_intent_info') or {}).get('main_intent')})
    return rows

def load_credentials():
    login=os.getenv('DATAFORSEO_LOGIN');password=os.getenv('DATAFORSEO_PASSWORD')
    if login and password:
        return login,password
    if login or password:
        raise ValueError('Both credential environment variables must be set together')
    configured=os.environ.get('DATAFORSEO_CREDENTIALS_FILE')
    if not configured:
        raise ValueError('Configure credential environment variables or DATAFORSEO_CREDENTIALS_FILE')
    path=Path(configured).expanduser()
    if not path.is_file():
        raise ValueError('Local credentials unavailable; configure once on this machine')
    if path.stat().st_mode & 0o077:
        raise ValueError('Credential file must be private (permissions 600)')
    try:
        saved=json.loads(path.read_text())
    except (OSError,ValueError):
        raise ValueError('Cannot read local credential configuration') from None
    login=saved.get('login');password=saved.get('password')
    if not isinstance(login,str) or not isinstance(password,str) or not login or not password:
        raise ValueError('Local credential configuration is incomplete')
    return login,password

def main():
    p=argparse.ArgumentParser();p.add_argument('keywords');p.add_argument('--location',type=int,required=True);p.add_argument('--language',required=True);p.add_argument('--out',required=True);p.add_argument('--live',action='store_true');a=p.parse_args()
    keys=json.loads(Path(a.keywords).read_text())
    if not isinstance(keys,list) or not keys or any(not isinstance(k,str) or not k.strip() for k in keys):p.error('Expected nonempty JSON array of keyword strings')
    keys=list(dict.fromkeys(k.strip().lower() for k in keys))
    if len(keys)>700 or any(len(k)>80 or len(k.split())>10 for k in keys):p.error('Limit: 700 keywords; 80 characters / 10 words each')
    body=[{'keywords':keys,'location_code':a.location,'language_code':a.language,'include_clickstream_data':False}]
    if not a.live:
        print(json.dumps({'dry_run':True,'endpoint':URL,'request':body},ensure_ascii=False,indent=2));return
    try:login,password=load_credentials()
    except ValueError as e:p.error(str(e))
    out=Path(a.out)
    if out.exists() and any(out.iterdir()):p.error('Use a fresh output folder to preserve prior evidence')
    out.mkdir(parents=True,exist_ok=True)
    auth=base64.b64encode((login+':'+password).encode()).decode()
    req=urllib.request.Request(URL,data=json.dumps(body).encode(),headers={'Authorization':'Basic '+auth,'Content-Type':'application/json'})
    t=time.monotonic()
    try:
        with urllib.request.urlopen(req,timeout=40) as r:raw=json.load(r)
    except urllib.error.HTTPError as e:
        p.exit(1,f'HTTP {e.code}; no retry, no keyword data accepted\n')
    except urllib.error.URLError:
        p.exit(1,'Connection failed; no retry. Check account usage before repeating.\n')
    (out/'raw.json').write_text(json.dumps(raw,ensure_ascii=False,indent=2))
    try: rows=normalize(raw,keys,a.location,a.language)
    except ValueError as e:p.exit(1,str(e)+'\n')
    result={'provider':'DataForSEO','environment':'live','engine':'google','location_code':a.location,'language_code':a.language,'queried_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-t,2),'cost_usd':raw.get('cost'),'complete_count':sum(r['status']=='complete' for r in rows),'requested_count':len(keys),'rows':rows}
    (out/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({'complete_count':result['complete_count'],'requested_count':len(keys),'cost_usd':result['cost_usd']}))
if __name__=='__main__':main()
