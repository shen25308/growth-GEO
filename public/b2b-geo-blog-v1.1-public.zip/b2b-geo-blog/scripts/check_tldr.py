#!/usr/bin/env python3
"""Check TL;DR structure in explicit, already-rendered HTML files. No network or writes.

This does not assess truth, originality, summary fidelity, CSS visibility, or deployment.
"""
import argparse
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urljoin, urldefrag, urlsplit


class Node:
    def __init__(self, tag, attrs=None, parent=None):
        self.tag, self.attrs, self.parent = tag, dict(attrs or []), parent
        self.children = []

    def text(self):
        return ''.join(x.text() if isinstance(x, Node) else x for x in self.children)

    def walk(self):
        yield self
        for child in self.children:
            if isinstance(child, Node):
                yield from child.walk()


class Document(HTMLParser):
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.root = Node('document')
        self.stack = [self.root]
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs, self.stack[-1])
        self.stack[-1].children.append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def heading_key(text):
    return re.sub(r'[^\w]', '', text).casefold()


def ancestors(node):
    while node:
        yield node
        node = node.parent


def audit(html, body_id=None, article_class=None, summary_heading='TL;DR', require_toc=True):
    root = Document(html).root
    all_nodes = list(root.walk())
    errors = []
    if body_id:
        bodies = [n for n in all_nodes if n.attrs.get('id') == body_id]
    else:
        bodies = [n for n in all_nodes if n.tag == 'article' and (not article_class or article_class in n.attrs.get('class', '').split())]
    if len(bodies) != 1:
        return {'errors': ['Select exactly one body using --body-id or --article-class.'], 'points': 0}
    body = bodies[0]
    headings = [n for n in body.walk() if re.fullmatch(r'h[2-6]', n.tag)]
    summaries = [n for n in headings if heading_key(n.text()) == heading_key(summary_heading)]
    if len(summaries) != 1:
        return {'errors': [f'Expected one {summary_heading} heading in the body; found {len(summaries)}.'], 'points': 0}
    summary = summaries[0]
    if headings[0] is not summary:
        errors.append('The summary is not the first substantive body section.')
    ordered = list(body.walk())
    start = ordered.index(summary)
    end = next((i for i in range(start + 1, len(ordered)) if re.fullmatch(r'h[2-6]', ordered[i].tag)), len(ordered))
    points = [n for n in ordered[start + 1:end] if n.tag == 'li' and n.text().strip() and not any(p.tag == 'li' for p in ancestors(n.parent))]
    if not 3 <= len(points) <= 4:
        errors.append(f'Expected 3–4 non-empty top-level summary points; found {len(points)}.')
    if any('hidden' in n.attrs or n.attrs.get('aria-hidden') == 'true' for n in ancestors(summary)):
        errors.append('The summary is explicitly hidden.')
    canonical = next((n.attrs.get('href', '') for n in all_nodes if n.tag == 'link' and 'canonical' in n.attrs.get('rel', '').split()), '')
    anchor = None
    for node in ancestors(summary):
        if node is body:
            break
        if node.attrs.get('id'):
            anchor = node.attrs['id']
            break
    if not anchor:
        errors.append('The summary needs its own stable heading or section id.')
    elif sum(n.attrs.get('id') == anchor for n in all_nodes) != 1:
        errors.append('The summary id is duplicated.')
    if require_toc and anchor:
        links = []
        for n in all_nodes:
            href = n.attrs.get('href', '')
            if n.tag != 'a' or not any(p.tag in {'nav', 'aside'} for p in ancestors(n.parent)):
                continue
            if unquote(urlsplit(href).fragment) != anchor:
                continue
            if href.startswith('#') or (canonical and urldefrag(urljoin(canonical, href))[0] == urldefrag(canonical)[0]):
                links.append(n)
        if not links:
            errors.append('No same-page summary link was found in a nav or aside.')
    return {'errors': errors, 'points': len(points), 'anchor': anchor}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+', type=Path)
    parser.add_argument('--body-id')
    parser.add_argument('--article-class')
    parser.add_argument('--summary-heading', default='TL;DR')
    parser.add_argument('--no-toc', action='store_true', help='Only for a deliverable intentionally lacking a table of contents.')
    args = parser.parse_args()
    results = []
    for file in args.files:
        try:
            result = audit(file.read_text(encoding='utf-8'), args.body_id, args.article_class, args.summary_heading, not args.no_toc)
        except (OSError, UnicodeError) as error:
            result = {'errors': [str(error)], 'points': 0}
        results.append({'file': str(file), **result})
    print(json.dumps({'pages_checked': len(results), 'results': results, 'scope': 'Rendered HTML structure only; content and browser review still required.'}, ensure_ascii=False, indent=2))
    return int(any(result['errors'] for result in results))


if __name__ == '__main__':
    sys.exit(main())
